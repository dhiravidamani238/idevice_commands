#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""Created on Fri Dec 17 2021 14:55:55 by codeskyblue
"""

from functools import lru_cache

cache = lru_cache(maxsize=None)